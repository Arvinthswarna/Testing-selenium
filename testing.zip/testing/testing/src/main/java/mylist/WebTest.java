package mylist;

import org.openqa.selenium.WebDriver;
public class WebTest {
	public static void main(String[] args) {
		System.setPriority("WebDriver.go ","C:\\Users\\Hemanth Devangam\\Documents\\axis\\axisb8\\libraries\\selinium drivers\\geckodriver-v0.32.0-win-aarch64")
		WebDriver obj = new FirefoxDriver();
	}

}
